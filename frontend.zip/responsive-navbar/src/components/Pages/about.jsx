import React from "react";

export class about extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">About Us</div>
        <div className="content">
          <p>
            Express yourself. Tumblr is your canvas. Post text, photos, GIFs,
            videos, live videos, audio, anything. Make your own GIFs. Cover them
            in stickers and text, if you like. Be yourself. Look however you
            want. Customize your Tumblr’s colors, fonts, layout, everything.
            Follow whatever topics you’re interested in. Find new ones you
            didn’t even know exist. Connect with your people. Join millions of
            people in millions of communities across millions of #tags. See
            something you love? Reblog it to your Tumblr and start a
            conversation. Or just lurk, if you’re feeling shy. No big deal. It’s
            a whole big world in here. Come on in.
          </p>
        </div>
      </div>
    );
  }
}
export default about;
