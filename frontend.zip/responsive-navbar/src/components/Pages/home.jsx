import React from "react";
import "./homepage.css";
import { Glyphicon } from "react-bootstrap";

export class home extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const mystyle = {};
    return (
      <div className="base-container" ref={this.props.containerRef}>
        {/* <div className="header">Welcome to Innovation Campus</div>
        <div className="content">
          <p>COME | COLABORATE | DEVELOPE </p>
        </div> */}

        <div class="headerContent">
          <div class="headerText">
            <h1>Innovation Campus</h1>
            <label>Ideas To Reality</label>
          </div>
        </div>
        <div class="paraText">
          <h1>Let's get started!</h1>
          <br />
          <label>
            Innovation at you finger tip.Ideas from different mind found in a
            single place.
          </label>
          <br />
          <label>
            Get started by helping someone to make their ideas be a reality.
          </label>
          <br />
          <label>
            If you have a idea then making it a reality is a click away.
          </label>
        </div>
        <div class="container">
          <div class="col-md-7">
            <label class="commonText">The Developers</label>
            <br />

            <span
              class="glyphicon glyphicon-envelope"
              style={{ mystyle }}
            ></span>
            <a href="#"> Nitin.Dhiman | nitindhiman832@gmail.com</a>
            <br />
          </div>
        </div>
      </div>
    );
  }
}
export default home;
