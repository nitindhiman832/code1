import React from "react";

export class Dashboard extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">Dashboard</div>
        <div className="content">
          <div class="icon-container">
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            {/* <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p>
            <p>dash content</p> */}
          </div>
        </div>
      </div>
    );
  }
}
export default Dashboard;
