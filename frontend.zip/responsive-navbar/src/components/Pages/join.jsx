import React from "react";
import loginImg from "../../login.svg";
import GoogleBtn from "../Login/GoogleBtn";
import FacebookBtn from "../Login/FacebookBtn";

export class join extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">Join Here</div>
        <div className="content">
          <div className="image">
            <img src={loginImg} />
          </div>
          <div className="form">
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input type="text" name="username" placeholder="username" />
            </div>
            {/* <div className="form-group">
              <label htmlFor="email">Email</label>
              <input type="text" name="email" placeholder="email" />
            </div> */}
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="text" name="password" placeholder="password" />
            </div>
          </div>
        </div>
        <div className="join-btn">
          <button type="button" className="btn">
            Join Now ! OR
          </button>
          <div>
            {" "}
            <GoogleBtn />
            <FacebookBtn />
          </div>
        </div>
      </div>
    );
  }
}
export default join;
